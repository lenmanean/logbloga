# Contract Templates

Ready-to-use contract templates for freelancers (scope, payment, revisions).

## Contents

- Service agreement templates
- Customize with your scope, rate, and terms
- Use with Hello Bonsai or similar for e-signatures

See the Freelancing package Level 2 guides for client management and contracts.
